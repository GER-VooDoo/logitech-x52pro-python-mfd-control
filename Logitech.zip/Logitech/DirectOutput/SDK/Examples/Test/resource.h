//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Test.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_X52PRO                      201
#define IDD_FIP                         202
#define IDD_X56_GROUP                   203
#define IDC_LIST1                       1000
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_EDIT3                       1003
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define IDC_BUTTON3                     1005
#define IDC_BUTTON4                     1006
#define IDC_BUTTON_TEXT                 1007
#define IDC_CHECK1                      1008
#define IDC_CHECK2                      1009
#define IDC_STATIC_BRIGHTNESS           1009
#define IDC_CHECK3                      1010
#define IDC_EDIT_BRIGHTNESS             1010
#define IDC_CHECK4                      1011
#define IDC_STATIC_RED                  1011
#define IDC_CHECK5                      1012
#define IDC_EDIT_RED                    1012
#define IDC_CHECK6                      1013
#define IDC_STATIC_GREEN                1013
#define IDC_CHECK7                      1014
#define IDC_EDIT_GREEN                  1014
#define IDC_CHECK8                      1015
#define IDC_STATIC_BLUE                 1015
#define IDC_CHECK9                      1016
#define IDC_EDIT4                       1016
#define IDC_EDIT_BLUE                   1016
#define IDC_CHECK10                     1017
#define IDC_SOFTBUTTON                  1017
#define IDC_CHECK11                     1018
#define IDC_CHECK12                     1019
#define IDC_CHECK13                     1020
#define IDC_CHECK14                     1021
#define IDC_CHECK15                     1022
#define IDC_CHECK16                     1023
#define IDC_CHECK17                     1024
#define IDC_CHECK18                     1025
#define IDC_CHECK19                     1026
#define IDC_CHECK20                     1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
